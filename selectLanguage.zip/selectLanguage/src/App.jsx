// Consume LanguageContext to show translated text and radio options
import React, { useContext } from "react";
import LanguageProvider from "./LanguageProvider";
import LanguageContext from "./LanguageContext";

const translations = {
  en: "Hello, Welcome to our App 👋",
  hi: "नमस्ते, हमारे ऐप में आपका स्वागत है 👋",
  fr: "Bonjour, bienvenue dans notre application 👋",
};

const AppContent = () => {
  // Extract selected language and changeLanguage function from context
  const { language, changeLanguage } = useContext(LanguageContext);

  return (
    <div style={{ textAlign: "center", marginTop: "80px" }}>
      {/* Display translated text based on selected language */}
      <h1>{translations[language]}</h1>

      {/* Radio buttons to switch language */}
      <div style={{ marginTop: "20px" }}>
        <label>
          <input
            type="radio"
            value="en"
            checked={language === "en"}
            onChange={() => changeLanguage("en")}
          />
          English
        </label>{" "}
        <label>
          <input
            type="radio"
            value="hi"
            checked={language === "hi"}
            onChange={() => changeLanguage("hi")}
          />
          Hindi
        </label>{" "}
        <label>
          <input
            type="radio"
            value="fr"
            checked={language === "fr"}
            onChange={() => changeLanguage("fr")}
          />
          French
        </label>
      </div>
    </div>
  );
};

const App = () => {
  return (
    // Wrap whole app in LanguageProvider so context is available
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
};

export default App;
