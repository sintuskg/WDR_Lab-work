// Create and export a Context for multi-language selection
import { createContext } from "react";

const LanguageContext = createContext();
export default LanguageContext;
