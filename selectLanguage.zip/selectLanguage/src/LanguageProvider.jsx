// Provider component that stores and manages global language state
import React, { useState } from "react";
import LanguageContext from "./LanguageContext";

const LanguageProvider = ({ children }) => {
  // Default selected language is English ("en")
  const [language, setLanguage] = useState("en");

  // Function to change selected language
  const changeLanguage = (lang) => {
    setLanguage(lang);
  };

  return (
    // Pass both selected language and function to update it
    <LanguageContext.Provider value={{ language, changeLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
};

export default LanguageProvider;
