// Contact Form using react-hook-form with Reset and Prefill Example Values

import React from "react";
import { useForm } from "react-hook-form";

const App = () => {
  // Initialize useForm hook
  const { register, handleSubmit, reset, setValue } = useForm();

  // On form submit → show form data in console (or send to backend later)
  const onSubmit = (data) => {
    console.log("Submitted Form:", data);
    alert("Form submitted successfully!");
  };

  // Prefill fields using setValue()
  const fillExampleData = () => {
    setValue("fullName", "Rahul Sharma");
    setValue("message", "Hello, I would like to know more about your services.");
  };

  return (
    <div className="container">
      <h2>Contact Form</h2>

      {/* handleSubmit validates and then calls onSubmit */}
      <form onSubmit={handleSubmit(onSubmit)}>
        {/* Full Name Field */}
        <label>Full Name:</label>
        <input
          type="text"
          placeholder="Enter your full name"
          {...register("fullName", { required: true })}
        />

        {/* Message Field */}
        <label>Message:</label>
        <textarea
          placeholder="Write your message here"
          {...register("message", { required: true })}
        ></textarea>

        {/* Buttons Section */}
        <div className="buttons">
          <button type="submit">Submit</button>

          {/* reset() clears all form fields */}
          <button type="button" onClick={() => reset()}>
            Reset
          </button>

          {/* Prefill example data */}
          <button type="button" onClick={fillExampleData}>
            Fill Example Data
          </button>
        </div>
      </form>
    </div>
  );
};

export default App;
