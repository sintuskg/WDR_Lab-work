// Registration Form using react-hook-form with validation and error display

import React, { useState } from "react";
import { useForm } from "react-hook-form";

const App = () => {
  // Initialize useForm hook
  const {
    register,      // register fields
    handleSubmit,  // handle submit event
    formState: { errors } // validation errors
  } = useForm();

  // To store submitted data
  const [submittedData, setSubmittedData] = useState(null);

  // On form submit → save submitted data
  const onSubmit = (data) => {
    setSubmittedData(data);
  };

  return (
    <div style={{ width: "350px", margin: "50px auto", textAlign: "left" }}>
      <h2>Registration Form</h2>

      {/* handleSubmit validates before calling onSubmit */}
      <form onSubmit={handleSubmit(onSubmit)}>
        {/* Name Field */}
        <label>Name:</label>
        <input
          type="text"
          {...register("name", { required: true })} // validation rule: required
        />
        {/* Error Message */}
        {errors.name && <p style={{ color: "red" }}>Name is required</p>}

        {/* Email Field */}
        <label style={{ marginTop: "10px" }}>Email:</label>
        <input
          type="email"
          {...register("email", {
            required: true,                // required
            pattern: /^\S+@\S+\.\S+$/      // valid email format regex
          })}
        />
        {/* Error Message */}
        {errors.email && (
          <p style={{ color: "red" }}>
            {errors.email.type === "required"
              ? "Email is required"
              : "Enter a valid email"}
          </p>
        )}

        {/* Password Field */}
        <label style={{ marginTop: "10px" }}>Password:</label>
        <input
          type="password"
          {...register("password", {
            required: true, // required
            minLength: 6    // min length rule
          })}
        />
        {/* Error Message */}
        {errors.password && (
          <p style={{ color: "red" }}>
            Password must be at least 6 characters
          </p>
        )}

        {/* Submit Button */}
        <button type="submit" style={{ marginTop: "15px" }}>
          Register
        </button>
      </form>

      {/* Display submitted data below form */}
      {submittedData && (
        <div style={{ marginTop: "25px", padding: "10px", border: "1px solid gray" }}>
          <h3>Submitted Data:</h3>
          <p><b>Name:</b> {submittedData.name}</p>
          <p><b>Email:</b> {submittedData.email}</p>
          <p><b>Password:</b> {submittedData.password}</p>
        </div>
      )}
    </div>
  );
};

export default App;
