import React, { useContext } from "react";
import ThemeProvider from "./ThemeProvider";
import ThemeContext from "./ThemeContext";

const AppContent = () => {
  const { theme, toggleTheme } = useContext(ThemeContext);

  const styles = {
    height: "100vh",
    backgroundColor: theme === "light" ? "#ffffff" : "#000000",
    color: theme === "light" ? "#000000" : "#ffffff",
    textAlign: "center",
    paddingTop: "100px",
    transition: "0.4s",
  };

  return (
    <div style={styles}>
      <h1>{theme.toUpperCase()} MODE</h1>
      <button onClick={toggleTheme}>
        Switch To {theme === "light" ? "Dark" : "Light"} Mode
      </button>
    </div>
  );
};

const App = () => {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
};

export default App;
