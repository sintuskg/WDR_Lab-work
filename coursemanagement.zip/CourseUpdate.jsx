import React, { useState } from "react";

const CourseUpdate = ({ courses, updateCourse }) => {
  const [selected, setSelected] = useState("");
  const [name, setName] = useState("");
  const [duration, setDuration] = useState("");

  const handleUpdate = () => {
    updateCourse(selected, { name, duration });
  };

  return (
    <div className="box">
      <h2>Course Update</h2>

      <select onChange={(e) => setSelected(Number(e.target.value))}>
        <option>Select Course</option>
        {courses.map((c) => (
          <option key={c.id} value={c.id}>{c.name}</option>
        ))}
      </select>

      <input
        type="text"
        placeholder="New Course Name"
        onChange={(e) => setName(e.target.value)}
      />

      <input
        type="text"
        placeholder="New Duration"
        onChange={(e) => setDuration(e.target.value)}
      />

      <button onClick={handleUpdate}>Update</button>
    </div>
  );
};

export default CourseUpdate;
