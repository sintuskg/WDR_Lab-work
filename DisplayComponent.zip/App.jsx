// import Student from '/Student.jsx';
// function App(){
//   //to design UI
//   return(
//     <div>
//       This is first Page
//       {/*--Using component*/}
//       <Student name="Akash" age={14}/>
//     </div>
//   );
// }
// export default App;


// import State_Variable_example from "./State_Variable_example.jsx"
// function App(){
//     //ui design
//     return
//     (
//         <div>
//             <State_Variable_example />
//         </div>
//     );

// }
// export default App

// import TextFieldExample from "./TextFieldExample";

// function App() {
//   return (
//     <div>
//       <TextFieldExample />
//     </div>
//   );
// }

// export default App;
// import React from "react";
// import StudentForm from "./StudentForm";

// function App() {
//   return (
//     <div>
//       <h1>Welcome to My React App</h1>
//       <StudentForm />
//     </div>
//   );
// }

// export default App;




import { useState } from "react";
import FormComponent from "./FormComponent";
import DisplayComponent from "./DisplayComponent";

function App() {
  const [formData, setFormData] = useState({});

  return (
    <div>
      <FormComponent onSubmit={(data) => setFormData(data)} />
      <DisplayComponent data={formData} />
    </div>
  );
}

export default App;
